import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../../../components/NavBar/AdminNavBar';
import { HorseForm } from '../../../components/HorseForm/HorseForm';
import { useHorseStore } from '../../../store/useHorseStore';
import {type HorseFormData, type Difficulty } from '../../../types/Horse';
import styles from './HorseDetailPage.module.css';

const difficultyClass: Record<Difficulty, string> = {
  Easy:   styles.badgeEasy,
  Medium: styles.badgeMedium,
  Hard:   styles.badgeHard,
};

export const HorseDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getHorseById, updateHorse, removeHorse } = useHorseStore();

  const [showEdit, setShowEdit] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const horse = getHorseById(id ?? '');

  if (!horse) {
    return (
      <div className={styles.page}>
        <Navbar />
        <div className={styles.content}>
          <p className={styles.notFound}>Horse not found.</p>
          <div style={{ textAlign: 'center', marginTop: 16 }}>
            <button
              className={styles.btnEdit}
              onClick={() => navigate('/horses')}
            >
              Back to horses
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleEdit = (data: HorseFormData) => {
    updateHorse(horse.id, data);
    setShowEdit(false);
  };

  const handleDelete = () => {
    removeHorse(horse.id);
    navigate('/horses');
  };

  const statusBadge = () => {
    if (horse.inTraining)
      return <span className={`${styles.badge} ${styles.badgeTraining}`}>In Training</span>;
    if (horse.isAvailable)
      return <span className={`${styles.badge} ${styles.badgeAvail}`}>Available</span>;
    return <span className={`${styles.badge} ${styles.badgeUnavail}`}>Unavailable</span>;
  };

  const age = () => {
    const dob = new Date(horse.dateOfBirth);
    const diff = Date.now() - dob.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24 * 365));
  };

  const guidanceKeys = ['leisure', 'training', 'competition'] as const;

  return (
    <div className={styles.page}>
      <Navbar />

      <div className={styles.content}>
        <button className={styles.backBtn} onClick={() => navigate('/horses')}>
          ← Back to horses
        </button>

        <div className={styles.card}>
          {/* HEADER */}
          <div className={styles.cardHeader}>
            <div>
              <div className={styles.horseName}>{horse.name}</div>
              <div className={styles.horseId}>ID: #{horse.id}</div>
            </div>
            <div className={styles.headerBadges}>
              <span className={`${styles.badge} ${difficultyClass[horse.difficulty]}`}>
                {horse.difficulty}
              </span>
              {statusBadge()}
              <span className={styles.badge} style={{ background: 'rgba(234,224,215,0.15)', color: 'var(--cream)' }}>
                {horse.recommendedFor === 'Both' ? 'All riders' : horse.recommendedFor}
              </span>
            </div>
          </div>

          {/* BODY */}
          <div className={styles.cardBody}>
            <div className={styles.grid}>
              <div className={styles.fieldGroup}>
                <span className={styles.fieldLabel}>Breed</span>
                <span className={styles.fieldValue}>{horse.breed}</span>
              </div>

              <div className={styles.fieldGroup}>
                <span className={styles.fieldLabel}>Weight</span>
                <span className={styles.fieldValue}>{horse.weight} kg</span>
              </div>

              <div className={styles.fieldGroup}>
                <span className={styles.fieldLabel}>Date of birth</span>
                <span className={styles.fieldValue}>
                  {new Date(horse.dateOfBirth).toLocaleDateString('en-GB', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </span>
              </div>

              <div className={styles.fieldGroup}>
                <span className={styles.fieldLabel}>Age</span>
                <span className={styles.fieldValue}>{age()} years old</span>
              </div>

              <div className={`${styles.fieldGroup} ${styles.about}`}>
                <span className={styles.fieldLabel}>About</span>
                <p className={styles.aboutText}>{horse.about}</p>
              </div>
            </div>

            <hr className={styles.divider} />

            {/* GUIDANCE */}
            <p className={styles.sectionTitle}>No trainer guidance needed for</p>
            <div className={styles.guidanceRow}>
              {guidanceKeys.map((key) => (
                <div key={key} className={styles.guidanceTag}>
                  <div

                  />
                  {key.charAt(0).toUpperCase() + key.slice(1)}
                </div>
              ))}
            </div>
          </div>

          {/* FOOTER */}
          <div className={styles.cardFooter}>
            <button
              className={styles.btnDelete}
              onClick={() => setShowDeleteConfirm(true)}
            >
              Delete horse
            </button>
            <button
              className={styles.btnEdit}
              onClick={() => setShowEdit(true)}
            >
              Edit horse
            </button>
          </div>
        </div>
      </div>

      {/* EDIT MODAL */}
      {showEdit && (
        <div className={styles.overlay}>
          <HorseForm
            initial={horse}
            onSubmit={handleEdit}
            onCancel={() => setShowEdit(false)}
          />
        </div>
      )}

      {/* DELETE CONFIRM */}
      {showDeleteConfirm && (
        <div className={styles.overlay}>
          <div
            style={{
              background: 'var(--white)',
              borderRadius: 'var(--radius-lg)',
              padding: '36px',
              maxWidth: '420px',
              width: '100%',
              textAlign: 'center',
              boxShadow: 'var(--shadow-lg)',
            }}
          >
            <p style={{ fontFamily: 'var(--font-serif)', fontSize: '20px', color: 'var(--dark-earth)', marginBottom: '12px' }}>
              Remove {horse.name}?
            </p>
            <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '28px', lineHeight: '1.6' }}>
              This action cannot be undone. The horse will be permanently
              removed from the system.
            </p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                style={{ background: 'transparent', border: '1.5px solid var(--border)', color: 'var(--text-muted)', borderRadius: 'var(--radius-md)', padding: '10px 28px', fontSize: '14px', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                style={{ background: 'var(--danger)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', padding: '10px 28px', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}
              >
                Yes, remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};