import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../../components/NavBar/AdminNavBar';
import { HorseForm } from '../../components/HorseForm/HorseForm';
import { useHorseStore } from '../../store/useHorseStore';
import { type HorseFormData, type Difficulty } from '../../types/Horse';
import styles from './HorsesPage.module.css';

const PAGE_SIZE = 5;

const difficultyClass: Record<Difficulty, string> = {
  Easy:   styles.badgeEasy,
  Medium: styles.badgeMedium,
  Hard:   styles.badgeHard,
};

export const HorsesPage = () => {
  const navigate = useNavigate();
  const { horses, addHorse, removeHorse } = useHorseStore();

  const [currentPage, setCurrentPage] = useState(1);
  const [showAddForm, setShowAddForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(horses.length / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);
  const paginated = horses.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const handleAdd = (data: HorseFormData) => {
    addHorse(data);
    setShowAddForm(false);
    setCurrentPage(1);
  };

  const handleDeleteConfirm = () => {
    if (deleteId) {
      removeHorse(deleteId);
      setDeleteId(null);
      // stay on current page unless it's now empty
      const remaining = horses.length - 1;
      const newTotal = Math.max(1, Math.ceil(remaining / PAGE_SIZE));
      if (safePage > newTotal) setCurrentPage(newTotal);
    }
  };

  const statusBadge = (horse: typeof horses[0]) => {
    if (horse.inTraining)
      return <span className={`${styles.badge} ${styles.badgeTraining}`}>In Training</span>;
    if (horse.isAvailable)
      return <span className={`${styles.badge} ${styles.badgeAvail}`}>Available</span>;
    return <span className={`${styles.badge} ${styles.badgeUnavail}`}>Unavailable</span>;
  };

  return (
    <div className={styles.page}>
      <Navbar />

      <div className={styles.content}>
        <div className={styles.header}>
          <div>
            <h1 className={styles.title}>Horses</h1>
            <p className={styles.subtitle}>
              {horses.length} horse{horses.length !== 1 ? 's' : ''} in the system
            </p>
          </div>
          <button className={styles.btnAdd} onClick={() => setShowAddForm(true)}>
            + Add new horse
          </button>
        </div>

        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Breed</th>
                <th>Difficulty</th>
                <th>Weight</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={7}>
                    <div className={styles.empty}>
                      No horses found. Add one to get started.
                    </div>
                  </td>
                </tr>
              ) : (
                paginated.map((horse) => (
                  <tr key={horse.id}>
                    <td className={styles.idCell}>#{horse.id}</td>
                    <td className={styles.nameCell}>{horse.name}</td>
                    <td>{horse.breed}</td>
                    <td>
                      <span className={`${styles.badge} ${difficultyClass[horse.difficulty]}`}>
                        {horse.difficulty}
                      </span>
                    </td>
                    <td>{horse.weight} kg</td>
                    <td>{statusBadge(horse)}</td>
                    <td>
                      <div className={styles.actions}>
                        <button
                          className={styles.btnDetail}
                          onClick={() => navigate(`/horses/${horse.id}`)}
                        >
                          View
                        </button>
                        <button
                          className={styles.btnDelete}
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeleteId(horse.id);
                          }}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* PAGINATION */}
          <div className={styles.pagination}>
            <span className={styles.pageInfo}>
              Page {safePage} of {totalPages} · {horses.length} total
            </span>
            <div className={styles.pageButtons}>
              <button
                className={styles.pageBtn}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={safePage === 1}
              >
                ‹ Prev
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  className={`${styles.pageBtn} ${p === safePage ? styles.pageBtnActive : ''}`}
                  onClick={() => setCurrentPage(p)}
                >
                  {p}
                </button>
              ))}
              <button
                className={styles.pageBtn}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={safePage === totalPages}
              >
                Next ›
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ADD FORM MODAL */}
      {showAddForm && (
        <div className={styles.overlay}>
          <HorseForm
            onSubmit={handleAdd}
            onCancel={() => setShowAddForm(false)}
          />
        </div>
      )}

      {/* DELETE CONFIRM MODAL */}
      {deleteId && (
        <DeleteConfirmModal
          name={horses.find((h) => h.id === deleteId)?.name ?? ''}
          onConfirm={handleDeleteConfirm}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
};

// ---- inline confirmation modal ----
interface DeleteConfirmProps {
  name: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const DeleteConfirmModal = ({ name, onConfirm, onCancel }: DeleteConfirmProps) => (
  <div className={styles.overlay}>
    <div
      style={{
        background: 'var(--white)',
        borderRadius: 'var(--radius-lg)',
        padding: '36px',
        maxWidth: '420px',
        width: '100%',
        textAlign: 'center',
        boxShadow: 'var(--shadow-lg)',
      }}
    >
      <p
        style={{
          fontFamily: 'var(--font-serif)',
          fontSize: '20px',
          color: 'var(--dark-earth)',
          marginBottom: '12px',
        }}
      >
        Remove {name}?
      </p>
      <p
        style={{
          fontSize: '14px',
          color: 'var(--text-muted)',
          marginBottom: '28px',
          lineHeight: '1.6',
        }}
      >
        This action cannot be undone. The horse will be permanently removed
        from the system.
      </p>
      <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
        <button
          onClick={onCancel}
          style={{
            background: 'transparent',
            border: '1.5px solid var(--border)',
            color: 'var(--text-muted)',
            borderRadius: 'var(--radius-md)',
            padding: '10px 28px',
            fontSize: '14px',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          style={{
            background: 'var(--danger)',
            color: 'white',
            border: 'none',
            borderRadius: 'var(--radius-md)',
            padding: '10px 28px',
            fontSize: '14px',
            fontWeight: 700,
            cursor: 'pointer',
          }}
        >
          Yes, remove
        </button>
      </div>
    </div>
  </div>
);